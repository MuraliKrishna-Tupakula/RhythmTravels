java to DTbase connectivity
import java.sql.*;
class DBdemo
{
	public static void main(String args[])throws SQLException
	{
		//load driver =thin driver type4
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("oracle service id,portno,","IPC127","IPC127");
		Statement sct=con.createStatement();
		String sql="insert into student(1,'abc')";
		sct.executeUpdate(sql);
		System.out.println("Success");
	}
}
